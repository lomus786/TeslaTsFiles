@echo off
cd /d "%~dp0"
start "" "OCRHelper.exe"
exit
