(function () {
  let isOnBkgPaymentOptions = false;

  // Function to check if we're on bkgPaymentOptions and notify background
  function checkAndNotifyUrl() {
    console.log("Checking URL:", window.location.href);
    if (window.location.href.includes("bkgPaymentOptions")) {
      if (!isOnBkgPaymentOptions) {
        // Just navigated to bkgPaymentOptions
        isOnBkgPaymentOptions = true;
        console.log("Content script: Navigated to bkgPaymentOptions");
        chrome.runtime.sendMessage({
          type: "PAGE_CHANGED_TO_BKG_OPTIONS",
        });
      }
    } else {
      if (isOnBkgPaymentOptions) {
        // Left bkgPaymentOptions
        isOnBkgPaymentOptions = false;
        console.log("Content script: Left bkgPaymentOptions");
        chrome.runtime.sendMessage({
          type: "PAGE_LEFT_BKG_OPTIONS",
        });
      }
    }
  }

  // Check URL every 500ms for SPA navigation
  setInterval(checkAndNotifyUrl, 500);

  // Check initial URL state
  checkAndNotifyUrl();
})();
