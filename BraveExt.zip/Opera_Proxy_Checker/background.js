/*
    gadar Opera Proxy Checker

    Same behavior as your working Chrome extension:
    - Sends /ping
    - Waits for PaymentRedirect
    - Reads browser-stored cookies
    - Sends ONLY JSON.stringify(cookies) to /savecookies/
    - Handles proxy auth when C# /proxyconfig/ returns useProxy=true
*/

let gadarUseProxy = false;
let gadarProxyUsername = "";
let gadarProxyPassword = "";
let gadarSaveStarted = false;

async function sendPing() {
    try {
        await fetch("http://127.0.0.1:8080/ping");
    } catch (e) {
    }
}

async function loadProxyConfig() {
    try {
        const response = await fetch("http://127.0.0.1:8080/proxyconfig/", {
            cache: "no-store"
        });

        if (!response.ok) {
            gadarUseProxy = false;
            gadarProxyUsername = "";
            gadarProxyPassword = "";
            return;
        }

        const config = await response.json();

        gadarUseProxy = config.useProxy === true;
        gadarProxyUsername = config.username || "";
        gadarProxyPassword = config.password || "";
    } catch (e) {
        gadarUseProxy = false;
        gadarProxyUsername = "";
        gadarProxyPassword = "";
    }
}

sendPing();
setInterval(sendPing, 2000);

loadProxyConfig();
setInterval(loadProxyConfig, 2000);

chrome.webRequest.onAuthRequired.addListener(
    function(details) {
        if (!gadarUseProxy) {
            return {};
        }

        if (details.isProxy === false) {
            return {};
        }

        if (!gadarProxyUsername || !gadarProxyPassword) {
            return {};
        }

        return {
            authCredentials: {
                username: gadarProxyUsername,
                password: gadarProxyPassword
            }
        };
    },
    {
        urls: ["<all_urls>"]
    },
    ["blocking"]
);

function getCookies(domain) {
    return new Promise(function(resolve) {
        chrome.cookies.getAll(
            {
                domain: domain
            },
            function(cookies) {
                if (chrome.runtime.lastError) {
                    resolve([]);
                    return;
                }

                resolve(cookies || []);
            }
        );
    });
}

function uniqueCookies(cookies) {
    const output = [];
    const seen = {};

    for (let i = 0; i < cookies.length; i++) {
        const c = cookies[i];
        const key = c.domain + "|" + c.path + "|" + c.name;

        if (!seen[key]) {
            seen[key] = true;
            output.push(c);
        }
    }

    return output;
}

async function readAllIrctcCookies() {
    const c1 = await getCookies("irctc.co.in");
    const c2 = await getCookies(".irctc.co.in");
    const c3 = await getCookies("wps.irctc.co.in");
    const c4 = await getCookies(".wps.irctc.co.in");

    let all = [];
    all = all.concat(c1);
    all = all.concat(c2);
    all = all.concat(c3);
    all = all.concat(c4);

    return uniqueCookies(all);
}

chrome.webRequest.onCompleted.addListener(
    async function(details) {
        if (gadarSaveStarted) {
            return;
        }

        if (details.statusCode !== 200) {
            return;
        }

        gadarSaveStarted = true;

        console.log("Payment Redirect API Success! Extracting cookies...");

        const cookies = await readAllIrctcCookies();

        console.log("Captured Cookies:", cookies);

        if (!cookies || cookies.length === 0) {
            gadarSaveStarted = false;
            return;
        }

        try {
            let response = await fetch(
                "http://127.0.0.1:8080/savecookies/",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(cookies)
                }
            );

            if (response.ok) {
                console.log("Cookies sent successfully");
            } else {
                console.log("Server returned error:", response.status);
                gadarSaveStarted = false;
            }
        } catch (e) {
            console.error("Could not connect to C# server", e);
            gadarSaveStarted = false;
        }
    },
    {
        urls: [
            "*://*.wps.irctc.co.in/eticketing/PaymentRedirect*",
            "*://*.irctc.co.in/eticketing/PaymentRedirect*"
        ]
    }
);
