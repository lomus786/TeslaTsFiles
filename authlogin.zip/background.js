var config = {
  mode: "fixed_servers",
  rules: {
    singleProxy: {
      scheme: "http",
      host: "3b023a63c6731eec.xuw.as.pyproxy.io",
      port: parseInt("16666")
    },
    bypassList: ["localhost"]
  }
};

chrome.proxy.settings.set(
  { value: config, scope: "regular" },
  function () {}
);

chrome.webRequest.onAuthRequired.addListener(
  function (details) {
    return {
      authCredentials: {
        username: "dltafter11-zone-resi-region-in",
        password: "fdjhcdltafter11"
      }
    };
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);
